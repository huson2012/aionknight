#!/bin/sh
/usr/lib/jvm/java-6-sun/jre/bin/java -Xms512m -Xmx512m -cp ./libs/*:manager.jar com.aionengine.manager.Manager
